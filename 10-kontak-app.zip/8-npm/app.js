const validator = require('validator');
const chalk = require('chalk');

// console.log(validator.isEmail('m.fik1369@gmail.com'));
// console.log(validator.isMobilePhone('+628132472145', 'id-ID'));
// console.log(validator.isNumeric('628132472145'));

const nama = 'Ujang';
console.log(chalk.italic.bgCyan.black('Hello world!'));
const pesan = chalk`Lorem ipsum dolor {bgWhite sit amet} consectetur adipisicing elit. Sequi, ex! Saya ${nama}`;
console.log(pesan);