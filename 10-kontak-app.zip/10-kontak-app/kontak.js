const fs = require('fs');
const chalk = require('chalk');
const validator = require('validator');

// membuat folder data jika belum ada
const dirPath = './data';
if(!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath);
}

// membuat file kontak.json jika belum ada
const dataPath = './data/kontak.json';
if(!fs.existsSync(dataPath)) {
    fs.writeFileSync(dataPath, '[]', 'utf-8');
}

const simpanKontak = (nama, email, noTelp) => {
    const kontak = { nama, email, noTelp };
    const file = fs.readFileSync('data/kontak.json', 'utf-8');
    const kontakArr = JSON.parse(file);

    // cek duplikat
    const duplikat = kontakArr.find((k) => k.nama === nama);
    if(duplikat) {
        console.log(chalk.red.inverse.bold('Kontak sudah terdaftar, gunakan nama lain!'));
        return false;
    }

    // cek email
    if(email) {
        if(!validator.isEmail(email)) {
            console.log(chalk.red.inverse.bold('Email tidak valid!'));
            return false;
        }
    }

    // cek no telp
    if(!validator.isMobilePhone(noTelp, 'id-ID')) {
        console.log(chalk.red.inverse.bold('Nomor telepon tidak valid!'));
        return false;
    }


    kontakArr.push(kontak);
    fs.writeFileSync('data/kontak.json', JSON.stringify(kontakArr));
    console.log(chalk.green.inverse.bold('Terima kasih sudah memasukkan data.'));
};

module.exports = { simpanKontak };