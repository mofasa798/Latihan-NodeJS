const yargs = require('yargs');
const { simpanKontak } = require('./kontak');

yargs.command({
    command: 'add',
    describe: 'Menambahkan kontak baru',
    builder: {
        nama: {
            describe: 'Nama',
            demandOption: true,
            type: 'string',
        },
        email: {
            describe: 'Email',
            demandOption: false,
            type: 'string',
        },
        noTelp: {
            describe: 'Nomor Telepon',
            demandOption: true,
            type: 'string',
        },
    },
    handler(argv) {
        simpanKontak(argv.nama, argv.email, argv.noTelp);
        }
    },
);
yargs.parse();




// const kontak = require('./kontak');

// const main = async () => {
//     const nama = await kontak.tulisPertanyaan('Masukkan nama Anda: ');
//     const email = await kontak.tulisPertanyaan('Masukkan email Anda: ');
//     const noTelp = await kontak.tulisPertanyaan('Masukkan nomor telepon Anda: ');

//     kontak.simpanKontak(nama, email, noTelp);
// };
// main();